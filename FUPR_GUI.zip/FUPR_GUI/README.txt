📁 Project Structure:
- All .java files are inside `src/`
- All resources (images, numbers.txt) are in `resources/`
- All file paths are relative (e.g., "resources/numbers.txt")

✅ Please run the code from the root folder (FUPR_GUI) to avoid file not found issues.
